import numpy as np
from generation.config import DotheLoop, get_config	
import os
import sys
from mpi4py import MPI
from connec.comp_cmap import comp_connec
from postprocessK.comp_PostKeff import comp_postKeff
from shutil import copyfile
from solver.comp_Kperm_scale import comp_kperm_sub
from solver.Ndar import PetscP

def realization(job):

	if job==-1:
		return


	conffile='./config.ini'
	parser, iterables = get_config(conffile)
	start_job=int(parser.get('General',"startJob"))
	
	if job<start_job:
		return
	

	rdir='./'+parser.get('General',"simDir")+'/'
	datadir=rdir+str(job)+'/'
	create_dir(datadir,job)
	if job==0:
		copyfile(conffile,rdir+conffile[2:])

	genera=parser.get('Generation',"genera")
	if genera!='no':
		os.system('python ./tools/generation/fftma_gen.py '+ datadir +' '+str(job)+' '+conffile)

	
	nr= DotheLoop(job,parser, iterables)[3] -iterables['seeds'][0]

	Cconec=parser.get('Connectivity',"conec")
	if Cconec!='no':
		comp_connec(parser,datadir,nr)

	n_p=int(parser.get('Solver',"num_of_cores"))
	ref=int(parser.get('Solver',"ref"))
	solv=parser.get('Solver',"solve")
	Rtol=parser.get('Solver',"rtol")
	
	if solv!='no':
		if n_p>1:
			icomm=MPI.COMM_SELF.Spawn(sys.executable, args=['./tools/solver/Ndar.py',datadir,str(ref),'0',Rtol,'1'], maxprocs=n_p)
			icomm.Disconnect()
		else:
			PetscP(datadir,ref,'0',True,float(Rtol),0)
	

	compkperm=parser.get('K-Postprocess',"kperm")
	if compkperm!='no':
		print('start kperm')
		comp_kperm_sub(parser,datadir,nr)
	#print('finished job ' +str(job))

	postP=parser.get('K-Postprocess',"postprocess")
	if postP!='no':
		comp_postKeff(parser,datadir,nr)


	return

def create_dir(datadir,job):

	try:
		os.makedirs(datadir)
	except:
		print('Warning: Unable to create dir job: '+str(job))

	return




