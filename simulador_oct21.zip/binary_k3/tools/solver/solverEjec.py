import numpy as np
import sys
from Ndar import PetscP
import petsc4py
import math
import time
from mpi4py import MPI
from petsc4py import PETSc


if sys.argv[3]=='0':


	icomm = MPI.Comm.Get_parent()
	PetscP(sys.argv[1],int(sys.argv[2]),'0',True)
	icomm.Disconnect()



