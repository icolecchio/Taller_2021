import numpy as np
import sys

from FFTMA import gen



def fftmaGenerator(seed):


	typ=0  #structure du champ: 0=normal; 1=lognormal; 2=log-10
	dx, dy, dz = 1.0, 1.0, 1.0
	var=1	#Nbr de structure du variogramme
	alpha=1 #valeur exposant

	k=np.zeros(10)



	v1 = (var, 2, alpha, 1.0, 1.0, 1.0, 1, 0, 0, 0, 1, 0)  # coord des vecteurs de base (1 0 0) y (0 1 0)
	kkc=gen(1 , 100, 100, dx, dy, dz, seed, [v1], 0, 1, 0)  # 0, 1, 0 = mean, variance, typ	  #Generation of a correlated standard dsitribution N(0,1)
	print(np.mean(kkc),np.var(kkc))
	k=0

	return 

s=int(sys.argv[1])

fftmaGenerator(s)
fftmaGenerator(s)
