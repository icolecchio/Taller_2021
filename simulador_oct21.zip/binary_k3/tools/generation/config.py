import numpy as np
import configparser

import json

def get_config(conffile):


	parser = configparser.ConfigParser()
	parser.read(conffile)

	cons=json.loads(parser.get('Iterables',"connectivity"))
	ps=json.loads(parser.get('Iterables',"p"))
	lcs=json.loads(parser.get('Iterables',"lc"))
	variances=json.loads(parser.get('Iterables',"variances"))
	seeds=json.loads(parser.get('Iterables',"seeds"))

	seeds=np.arange(seeds[0],seeds[1]+seeds[0])
	ps=np.linspace(ps[0],ps[1],ps[2])/100

	iterables=dict()
	iterables['ps'] = ps
	iterables['seeds'] = seeds
	iterables['lcs'] = lcs
	iterables['variances'] = variances 
	iterables['cons'] = cons 
	return parser, iterables



def DotheLoop(job,parser,iterables):

	


	ps = iterables['ps'] 
	seeds = iterables['seeds'] 
	lcs = iterables['lcs']
	variances = iterables['variances'] 
	cons = iterables['cons']  

	if job==-1:
		if parser.get('Generation','binary')=='yes':
			if 0 not in cons:
				njobs=len(ps)*len(cons)*len(seeds)*len(lcs)
			else:
				njobs=len(ps)*(len(cons)-1)*len(seeds)*len(lcs)+len(ps)*len(seeds)
		else:
			if 0 not in cons:
				njobs=len(variances)*len(cons)*len(seeds)*len(lcs)
			else:
				njobs=len(variances)*(len(cons)-1)*len(seeds)*len(lcs)+len(variances)*len(seeds)

		return njobs

	i=0

	for con in cons:
		if con == 0:
			llcs=[0.000001]
		else:
			llcs=lcs
		for lc in llcs:
			if parser.get('Generation','binary')=='yes':
				for p in ps:
					for seed in seeds:
						if i==job:
							return [con,lc,p,seed]
						i+=1

			else:
				for v in variances:
					for seed in seeds:
						if i==job:
							return [con,lc,v,seed]
						i+=1
	return []


