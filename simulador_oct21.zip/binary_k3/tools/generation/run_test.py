import numpy as np
import os


for i in range(10):
	os.system("python test.py "+str(i))

