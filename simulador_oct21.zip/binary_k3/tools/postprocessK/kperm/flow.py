import numpy as np




def getKeff(pm,k,pbc,Nz):

	nx = k.shape[2]  #Pasar k sin bordes de k=0
	ny = k.shape[1]

	tz = 2*k[1,:,:]*k[0, :,:]/(k[0, :,:]+k[1,:,:])
	q=((pm[0,:,:]-pm[1,:,:])*tz).sum()
	area=ny*nx
	l=Nz
	keff=q*l/(pbc*area)
	return keff,q

