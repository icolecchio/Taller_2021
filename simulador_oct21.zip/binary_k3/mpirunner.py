import numpy as np
from mpi4py import MPI
#from tools.realization import realization
from tools.generation.config import DotheLoop, get_config
import os
import sys
from tools.Prealization import realization


def main():
	comm = MPI.COMM_WORLD
	rank = comm.Get_rank()
	pn = comm.Get_size()

	if pn==1:
		sequential()
		return
	if rank==0:
		manager()
	else:
		worker()
	return



def sequential():
	comm = MPI.COMM_WORLD
	conffile = './config.ini'
	parser,iterables = get_config(conffile)
	njobs = DotheLoop(-1,parser,iterables)
	start_job=0
	for job in range(start_job,njobs):
		realization(job)
	return

def manager():
	comm = MPI.COMM_WORLD
	conffile = './config.ini'
	parser,iterables = get_config(conffile)
	njobs = DotheLoop(-1,parser,iterables)
	start_job=0
	for job in range(start_job,njobs):
		dest=comm.recv(source=MPI.ANY_SOURCE)
		comm.send(job,dest=dest)
	for i in range(comm.Get_size()-1):
		dest=comm.recv(source=MPI.ANY_SOURCE)
		comm.send(-1,dest=dest)

	return

def worker():
	comm = MPI.COMM_WORLD
	rank = comm.Get_rank()
	job=1
	while job!=-1:
		comm.send(rank,dest=0)
		job =  comm.recv(source=0)
		realization(job)
	return


main()
