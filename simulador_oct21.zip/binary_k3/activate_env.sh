export PATH=$HOME/python/Python-2.7.13/:$PATH
export PYTHONPATH=$HOME/python/Python-2.7.13
export PATH=$HOME/.local/bin:$PATH
export PETSC_DIR=$HOME/soft/petsc 
