#!/usr/bin/env bash
#SBATCH -J coneclpp
#SBATCH -N 2 
#SBATCH --ntasks-per-node 32
#SBATCH --output %j_output.out
#SBATCH -p free-rider
#SBATCH -t 1-23:00:00
source activate_env.sh
ulimit -v  115343360 


mpirun -np 64 python mpirunner.py
